<!DOCTYPE html>
<html lang="es">
<head>
	<title>Laboratorio 4</title>
	<meta charset="utf-8">
	<h1 align="center" >ERROR</h1>
</head>
<body>
	<center>
		<br>
		<br>
		
	<h2>No se encontro</h2>
	</center>
</body>
</html>