<!DOCTYPE html>
<html lang='es'>
<head>
	<title>CodeIgniter curso</title>
</head>
<body>
