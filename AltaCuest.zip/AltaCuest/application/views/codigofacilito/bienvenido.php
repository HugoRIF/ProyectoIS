<!doctype html>
<html>
<body>
	<h1>Llamado desde el controlador. Código Facilito</h1>
	<?= getNombre() ?>
	<?= $Menu ?>
</body>
</html>
