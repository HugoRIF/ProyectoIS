<?php
mysqli_close($enlace);
/*echo 'Desonectado satisfactoriamente';*/
?>