<?php if (! defined('BASEPATH')) exit('No direct script access allowed');
	
	function getNombre(){
		return "<h1>Itzel</h1>";
	}
?>